<!-- /.container -->

<div class="container-fluid">

    
<!-- Footer -->
<footer >
    <div class="footer navbar-fixed-bottom pull-left">
    <div class="row">
        <div class="col-lg-12 ">
            <font color="white" ><p>Copyright &copy; Lukasz Kowal 2016</p></font>
        </div>
    </div>
        </div>
</footer>

</div>
<!-- /.container -->

